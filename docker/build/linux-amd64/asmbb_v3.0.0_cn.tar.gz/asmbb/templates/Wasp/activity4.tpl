[case:[special:lang]|
阅读带有标签[case:[Param]的主题列表|论坛首页|<a class="taglink online" href="/[Param]/">[Param]</a> 标签].]
[case:[special:lang]|
编辑回复 <a href="/[Param]/!by_id">#[Param]</a>.]
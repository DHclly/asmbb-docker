[css:navigation.css]
[css:login.css]

[case:[special:lang]|
  [equ:btnThreads=主题]
  [equ:ttlRegister=注册]
  [equ:phUser=用户名]
  [equ:phEmail=e-mail]
  [equ:phPass=密码]
  [equ:phPass2=再次输入密码]
  [equ:btnSubmit=注册]
  [equ:helpRegister=
    <p>与其选择一个容易记住的密码，不如选一个强密码并把它写在小纸条上。</p>
    <p>因为人们并不擅长记住随机字符，但非常擅长保管小纸片。</p>
    <p>只是别把纸条贴在显示器上！把它放进你的钱包里就好……</p>
    <p>……或者使用密码管理器软件。</p>
  ]
|
  [equ:btnThreads=主题]
  [equ:ttlRegister=注册]
  [equ:phUser=用户名]
  [equ:phEmail=e-mail]
  [equ:phPass=密码]
  [equ:phPass2=再次输入密码]
  [equ:btnSubmit=注册]
  [equ:helpRegister=
    <p>与其选择一个容易记住的密码，不如选一个强密码并把它写在小纸条上。</p>
    <p>因为人们并不擅长记住随机字符，但非常擅长保管小纸片。</p>
    <p>只是别把纸条贴在显示器上！把它放进你的钱包里就好……</p>
    <p>……或者使用密码管理器软件。</p>
  ]
|
  [equ:btnThreads=Темы]
  [equ:ttlRegister=Регистрация]
  [equ:phUser=Потребитель]
  [equ:phEmail=Адрес электронной почты]
  [equ:phPass=Пароль]
  [equ:phPass2=Пароль еще раз]
  [equ:btnSubmit=Регистрируй]
  [equ:helpRegister=
    <p>Лучше выбрать надежный пароль и написать его на бумаге, чем выбрать пароль, которого легко запомнить.</p>
    <p>Потому что люди не очень хорошо запоминают случайные символы, но хорошо умеют хранить бумаги.</p>
    <p>Только не наклеивайте пароль на монитор! Просто положите его в свой кошелек...</p>
    <p>...или используйте программу менеджера паролей.</p>
  ]
|
  [equ:btnThreads=Sujets]
  [equ:ttlRegister=Inscription]
  [equ:phUser=Nom d'utilisateur]
  [equ:phEmail=e-mail]
  [equ:phPass=Mot de passe]
  [equ:phPass2=Retaper le mot de passe]
  [equ:btnSubmit=Envoyer]
  [equ:helpRegister=
    <p>Choisir un mot de passe compliqué et l'écrire sur un papier vaut mieux qu'un mot de passe trop simple.</p>
    <p>Les humains ne sont pas vraiment capables de se souvenir de mot de cominaisons compliquées mais sont meilleurs pour garder des bouts de papiers.</p>
    <p>Mais ne les collez pas sur votre écran. Gardez-les plutôt dans une pochette ...</p>
    <p>... ou utiliser un gestionnaire de mots de passe.</p>
  ]
|
  [equ:btnThreads=Themen]
  [equ:ttlRegister=Registrieren]
  [equ:phUser=Benutzername]
  [equ:phEmail=E-Mail-Adresse]
  [equ:phPass=Passwort]
  [equ:phPass2=Passwort (noch mal)]
  [equ:btnSubmit=Absenden]
  [equ:helpRegister=
    <p>Ein starkes Passwort zu wählen und es aufzuschreiben ist besser als eines zu verwenden, das Sie sich leicht merken können.</p>
    <p>Weil Menschen nicht besonders gut darin sind, sich zufällige Zeichenfolgen zu merken, aber ziemlich gut darin, kleine Stücke Papier aufzubewahren.</p>
    <p>Aber kleben Sie es nicht an Ihren Bildschirm. Stecken Sie es einfach in Ihr Portemonnaie...</p>
    <p>... oder benutzen Sie irgendein Programm zur Passwortverwaltung-</p>
  ]
]


<div class="login">
  <div class="ui">
    <a class="ui" href="/">Threads</a>
  </div>
  <form class="register-block" method="post" action="/!register/">
    <h1>[const:ttlRegister]</h1>
    <p class="pi_nick"><input type="text" value="" placeholder="[const:phUser]" name="username" class="username" maxlength="256" autofocus></p>
    <p class="[case:[email_flag]|pi_email|pi_nick]"><input type="text" value="" placeholder="[const:phEmail]" name="email" class="email" maxlength="320"></p>
    <p class="pi_pass"><input type="password" value="" placeholder="[const:phPass]" name="password" class="password" maxlength="1024" autocomplete="off"></p>
    <p class="pi_pass"><input type="password" value="" placeholder="[const:phPass2]" name="password2" class="password" maxlength="1024" autocomplete="off"></p>
    <p class="pi_tick"><input type="text" value="[ticket]" name="ticket" id="ticket" class="ticket"></p>
    <label class="submit" for="submit">[const:btnSubmit]</label><input type="image" name="submit" id="submit" value="Submit">
  </form>
  <article>
    [const:helpRegister]
  </article>
</div>

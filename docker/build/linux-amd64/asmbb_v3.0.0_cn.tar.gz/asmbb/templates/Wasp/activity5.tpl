[case:[special:lang]|
浏览主题 "[html:[Link]]".]
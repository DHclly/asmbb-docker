[case:[special:lang]|
[case:[Param]|创建新主题|回复主题 "[html:[Link]]"].]
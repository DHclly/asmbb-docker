[case:[special:lang]|
删除回复 <a href="/[Param]/!by_id">#[Param]</a>.]

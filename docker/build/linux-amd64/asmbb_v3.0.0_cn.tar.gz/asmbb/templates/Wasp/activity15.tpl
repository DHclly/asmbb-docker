[case:[special:lang]|
发送重置请求.]
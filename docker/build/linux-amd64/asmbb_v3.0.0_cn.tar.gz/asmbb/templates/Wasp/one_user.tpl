[case:[special:lang]|
  [equ:ttlLong=很久以前]
  [equ:ttlNever=从未登录]
|
  [equ:ttlLong=很久以前]
  [equ:ttlNever=从未登录]
|
  [equ:ttlLong=очень давно]
  [equ:ttlNever=никогда]
|
  [equ:ttlLong=il y a longtemps]
  [equ:ttlNever=jamais]
|
  [equ:ttlLong=vor langer Zeit]
  [equ:ttlNever=niemals]
]

<tr>
  <td class="nick"><a href="/!userinfo/[url:[html:[UserName]]]">[usr:[UserName]]</a></td>
  <td class="avatar"><img src="/!avatar/[url:[html:[UserName]]]?v=[av_time]" alt="(ツ)"></td>
  <td>[case:[Skin]|default|[Skin]]</td>
  <td>[PostCount]</td>
  <td>[case:[fRegister]|[const:ttlLong]|[RegisterStr]]</td>
  <td>[case:[fLast]|[const:ttlNever]|[LastSeenStr]]</td>
</tr>
[css:login.css]
[css:userinfo.css]
[css:markdown.css]
[css:settings.css]

  <div class="user_desc post-text">
    <img class="profile_avatar" src="/!avatar/[url:[html:[UserName]]]?v=[AVer]" alt="(ツ)">
    <h1>[usr:[UserName]]</h1>
    [html:[minimag:[user_desc]]]
  </div>
  <div class="user_stat">
[case:[special:lang]|
    <h1>用户 [usr:[UserName]] 的资料：</h1>
    <ul>
      <li>最后在线时间：<b>[LastSeen]</b></li>
      <br>
      [case:[user_perm31]||<li>是 <b>管理员</b></li>]
      <li><b>[case:[user_perm0]|无法|可以]</b> <b>登录</b></li>
      <li><b>[case:[user_perm1]|无法|可以]</b> <b>阅读</b>论坛内容</li>
      <li><b>[case:[user_perm9]|无法|可以]</b> <b>下载</b>附件</li>

      <li><b>[case:[user_perm2]|无法|可以]</b> 在主题中<b>发表回复</b></li>
      <li><b>[case:[user_perm3]|无法|可以]</b> <b>创建</b>新主题</li>
      <li><b>[case:[user_perm10]|无法|可以]</b> <b>上传</b>附件</li>
      <li><b>[case:[user_perm4]|无法|可以]</b> <b>编辑</b>自己的回复</li>
      <li><b>[case:[user_perm6]|无法|可以]</b> <b>删除</b>自己的回复</li>

      <li><b>[case:[user_perm5]|无法|可以]</b> <b>编辑</b>他人的回复</li>
      <li><b>[case:[user_perm7]|无法|可以]</b> <b>删除</b>他人的回复</li>
      <li><b>[case:[user_perm8]|无法|可以]</b> <b>使用聊天功能</b></li>
      <li><b>[case:[user_perm11]|无法|可以]</b> <b>投票</b></li>
      <br>
      <li>已在论坛发表 [case:[totalposts]||<a href="/!search/?u=[url:[html:[UserName]]]" >]<b>[totalposts]</b> 条回[case:[totalposts]|复|复</a>|复</a>]</li>
    </ul>
|
    <h1>用户 [usr:[UserName]] 的资料：</h1>
    <ul>
      <li>最后在线时间：<b>[LastSeen]</b></li>
      <br>
      [case:[user_perm31]||<li>是 <b>管理员</b></li>]
      <li><b>[case:[user_perm0]|无法|可以]</b> <b>登录</b></li>
      <li><b>[case:[user_perm1]|无法|可以]</b> <b>阅读</b>论坛内容</li>
      <li><b>[case:[user_perm9]|无法|可以]</b> <b>下载</b>附件</li>

      <li><b>[case:[user_perm2]|无法|可以]</b> 在主题中<b>发表回复</b></li>
      <li><b>[case:[user_perm3]|无法|可以]</b> <b>创建</b>新主题</li>
      <li><b>[case:[user_perm10]|无法|可以]</b> <b>上传</b>附件</li>
      <li><b>[case:[user_perm4]|无法|可以]</b> <b>编辑</b>自己的回复</li>
      <li><b>[case:[user_perm6]|无法|可以]</b> <b>删除</b>自己的回复</li>

      <li><b>[case:[user_perm5]|无法|可以]</b> <b>编辑</b>他人的回复</li>
      <li><b>[case:[user_perm7]|无法|可以]</b> <b>删除</b>他人的回复</li>
      <li><b>[case:[user_perm8]|无法|可以]</b> <b>使用聊天功能</b></li>
      <li><b>[case:[user_perm11]|无法|可以]</b> <b>投票</b></li>
      <br>
      <li>已在论坛发表 [case:[totalposts]||<a href="/!search/?u=[url:[html:[UserName]]]" >]<b>[totalposts]</b> 条回[case:[totalposts]|复|复</a>|复</a>]</li>
    </ul>
|
    <h1>Статистика для [usr:[UserName]]:</h1>
    <ul>
      <li>Последний раз входил <b>[LastSeen]</b></li>
      <br>
      [case:[user_perm31]||<li>Является <b>администратором</b></li>]
      <li><b>[case:[user_perm0]|Не может|Может]</b> <b>входит</b></li>
      <li><b>[case:[user_perm1]|Не может|Может]</b> <b>читать</b> форум</li>
      <li><b>[case:[user_perm9]|Не может|Может]</b> <b>скачивать</b> прикрепленные файлы</li>

      <li><b>[case:[user_perm2]|Не может|Может]</b> <b>отвечать</b> в темах</li>
      <li><b>[case:[user_perm3]|Не может|Может]</b> <b>создавать</b> новые темы</li>
      <li><b>[case:[user_perm10]|Не может|Может]</b> <b>прикреплять</b> файлы</li>
      <li><b>[case:[user_perm4]|Не может|Может]</b> <b>редактировать</b> свои мнения</li>
      <li><b>[case:[user_perm6]|Не может|Может]</b> <b>удалять</b> свои мнения</li>

      <li><b>[case:[user_perm5]|Не может|Может]</b> <b>редактировать</b> чужие мнения</li>
      <li><b>[case:[user_perm7]|Не может|Может]</b> <b>удалять</b> чужие мнения</li>
      <li><b>[case:[user_perm8]|Не может|Может]</b> <b>входит в чат</b></li>
      <li><b>[case:[user_perm11]|Не может|Может]</b> <b>голосовать</b></li>
      <br>
      <li>Написал [case:[totalposts]||<a href="/!search/?u=[url:[html:[UserName]]]" >]<b>[totalposts]</b> мнени[case:[totalposts]|я|е</a>|я</a>] на форуме.</li>
    </ul>
|
    <h1>Statistiques de [usr:[UserName]]:</h1>
    <ul>
      <li>Dernière connexion le <b>[LastSeen]</b></li>
      <br>
      [case:[user_perm31]||<li>Est <b>administrateur</b></li>]
      <li>[case:[user_perm0]|<b>Ne</b> peut <b>pas</b>|Peut] <b>se connecter</b></li>
      <li>[case:[user_perm1]|<b>Ne</b> peut <b>pas</b>|Peut] <b>lire</b> les messages</li>
      <li>[case:[user_perm9]|<b>Ne</b> peut <b>pas</b>|Peut] <b>télécharger</b> des pièces jointes</li>

      <li>[case:[user_perm2]|<b>Ne</b> peut <b>pas</b>|Peut] <b>répondre</b> dans un sujet</li>
      <li>[case:[user_perm3]|<b>Ne</b> peut <b>pas</b>|Peut] <b>poster</b> un nouveau sujet</li>
      <li>[case:[user_perm10]|<b>Ne</b> peut <b>pas</b>|Peut] <b>attacher</b> des pièces jointes</li>
      <li>[case:[user_perm4]|<b>Ne</b> peut <b>pas</b>|Peut] <b>éditer</b> ses propres messages</li>
      <li>[case:[user_perm6]|<b>Ne</b> peut <b>pas</b>|Peut] <b>supprimer</b> ses propres messages</li>

      <li>[case:[user_perm5]|<b>Ne</b> peut <b>pas</b>|Peut] <b>éditer</b> d'autres messages</li>
      <li>[case:[user_perm7]|<b>Ne</b> peut <b>pas</b>|Peut] <b>supprimer</b> d'autres messages</li>
      <li>[case:[user_perm8]|<b>Ne</b> peut <b>pas</b>|Peut] <b>tchatter</b></li>
      <li>[case:[user_perm11]|<b>Ne</b> peut <b>pas</b>|Peut] <b>voter</b></li>
      <br>
      <li>A écrit [case:[totalposts]||<a href="/!search/?u=[url:[html:[UserName]]]" >]<b>[totalposts]</b> message[case:[totalposts]|s||s][case:[totalposts]||</a>] sur le forum.</li>
    </ul>
|
    <h1>Statistiken für [usr:[UserName]]:</h1>
    <ul>
      <li>Zuletzt gesehen am <b>[LastSeen]</b></li>
      <br>
      [case:[user_perm31]||<li>Ist ein <b>Administrator</b></li>]
      <li>Kann [case:[user_perm0]|<b>nicht</b> |]<b>sich anmelden</b></li>
      <li>Kann [case:[user_perm1]|<b>nicht</b> |]Beiträge <b>lesen</b></li>
      <li>Kann [case:[user_perm9]|<b>nicht</b> |]angehängte Dateien <b>herunterladen</b></li>

      <li>Kann [case:[user_perm2]|<b>nicht</b> |]auf Themen <b>antworten</b></li>
      <li>Kann [case:[user_perm3]|<b>nicht</b> |]neue Themen <b>eröffnen</b></li>
      <li>Kann [case:[user_perm10]|<b>nicht</b> |]Dateien <b>anhängen</b></li>
      <li>Kann [case:[user_perm4]|<b>nicht</b> |]seine eigenen Beiträge <b>ändern</b></li>
      <li>Kann [case:[user_perm6]|<b>nicht</b> |]seine eigenen Beiträge <b>löschen</b></li>

      <li>Kann [case:[user_perm5]|<b>nicht</b> |]fremde Beiträge <b>ändern</b></li>
      <li>Kann [case:[user_perm7]|<b>nicht</b> |]fremde Beiträge <b>löschen</b></li>
      <li>Kann [case:[user_perm8]|<b>nicht</b> |]<b>chatten</b></li>
      <li>Kann [case:[user_perm11]|<b>nicht</b> |]<b>abstimmen</b></li>
      <br>
      <li>Hat [case:[totalposts]||<a href="/!search/?u=[url:[html:[UserName]]]" >]<b>[totalposts]</b> Beitr[case:[totalposts]|äge|ag|äge][case:[totalposts]||</a>] im Forum verfasst.</li>
    </ul>
]
  </div>

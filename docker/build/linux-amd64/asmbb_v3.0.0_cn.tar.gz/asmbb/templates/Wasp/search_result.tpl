[case:[special:lang]|
  [equ:tThread=主题]
  [equ:tPost=回复]
  [equ:tMore=阅读更多...]
|
  [equ:tThread=主题]
  [equ:tPost=回复]
  [equ:tMore=阅读更多...]
|
  [equ:tThread=Тема]
  [equ:tPost=Сообщение]
  [equ:tMore=больше...]
|
  [equ:tThread=Sujet]
  [equ:tPost=Message]
  [equ:tMore=lire la suite...]
|
  [equ:tThread=Thema]
  [equ:tPost=Beitrag]
  [equ:tMore=weiterlesen...]
]

<div class="post">
  <div class="search_info">
    <img  width="32" height="32" class="unread" [case:[Unread]|src="[special:skin]/_images/onepost_gray.svg" alt="Rd">|src="[special:skin]/_images/onepost.svg" alt="URd">]
    <a class="user_name" href="/!userinfo/[url:[html:[UserName]]]">[usr:[UserName]]</>
    <img class="smallavatar" src="/!avatar/[url:[html:[UserName]]]?v=[AVer]" alt="(ツ)">
    <div class="changed">[PostTime]</div>
  </div>
  <div class="post_thread">
    [const:tThread]: <a href="../[case:[special:thread]|[Slug]/|]">[Caption]</a>
    [const:tPost]: <a href="../[rowid]/!by_id">#[rowid]</a>
  </div>
  <div class="post_sum">
    <pre>[content]</pre>
    <div class="post_link"><a href="../[rowid]/!by_id">[const:tMore]</a></div>
  </div>
</div>

[case:[special:lang]|
查看配置 <a href="/!userinfo/[url:[Param]]">[Param]</a>.]
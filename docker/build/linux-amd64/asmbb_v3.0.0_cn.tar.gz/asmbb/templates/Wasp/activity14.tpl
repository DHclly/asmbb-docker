[case:[special:lang]|
启动密码重置流程。]
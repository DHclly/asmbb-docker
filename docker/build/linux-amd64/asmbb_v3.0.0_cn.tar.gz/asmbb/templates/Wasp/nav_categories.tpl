[css:navigation.css]
[css:thread_list.css]

[case:[special:lang]|
  [equ:btnAll=所有主题]
  [equ:btnMarkRead=全部标记为已读]
  [equ:btnChat=聊天]
  [equ:btnSettings=设置]
  [equ:btnConsole=SQL 控制台]
|
  [equ:btnAll=所有主题]
  [equ:btnMarkRead=全部标记为已读]
  [equ:btnChat=聊天]
  [equ:btnSettings=设置]
  [equ:btnConsole=SQL 控制台]
|
  [equ:btnAll=Все темы]
  [equ:btnMarkRead=Отметить все]
  [equ:btnChat=Чат]
  [equ:btnSettings=Настройки]
  [equ:btnConsole=SQL конзоль]
|
  [equ:btnAll=Tous les sujets]
  [equ:btnMarkRead=Tout marquer comme lu]
  [equ:btnChat=Тchat]
  [equ:btnSettings=Paramètres]
  [equ:btnConsole=Console SQL]
|
  [equ:btnAll=Alle Themen]
  [equ:btnMarkRead=Alle als gelesen kennzeichnen]
  [equ:btnChat=Chat]
  [equ:btnSettings=Einstellungen]
  [equ:btnConsole=SQL-Konsole]
]

<div class="ui">
  <a class="ui left" href="/">[const:btnAll]</a>
  [case:[special:userid]  | |<a class="ui left" href="!markread">[const:btnMarkRead]</a>]
  [case:[special:canchat] | |<a class="ui left" href="/!chat">[const:btnChat]</a>]
  <span class="spacer"></span>
  [case:[special:isadmin] | |
    <a class="ui right" href="/!settings[special:urltag]">[const:btnSettings]</a>
    <a class="ui right" href="/!sqlite">[const:btnConsole]</a>
  ]
</div>

[case:[special:lang]|
用户正在执行管理员操作。]
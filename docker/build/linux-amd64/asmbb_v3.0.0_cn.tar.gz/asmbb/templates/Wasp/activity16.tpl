[case:[special:lang]|
正在重置密码.]
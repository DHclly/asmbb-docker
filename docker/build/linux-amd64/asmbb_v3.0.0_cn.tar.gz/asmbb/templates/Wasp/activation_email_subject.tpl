[case:[special:lang]|
[equ:subjActivation=账号激活链接]
[equ:subjEmail=邮箱变更确认]
[equ:subjPassword=密码重置请求]
]

[case:[operation]|[const:subjActivation]|[const:subjEmail]|[const:subjPassword]] http://[host]
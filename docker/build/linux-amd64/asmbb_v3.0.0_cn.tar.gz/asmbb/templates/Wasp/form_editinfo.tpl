
[case:[special:lang]|
  [equ:hdrDesc=描述：<span class="small">（支持格式化文本）</span>]
  [equ:hdrPermissions=用户权限：]
  [equ:pLogin=登录]
  [equ:pRead=阅读]
  [equ:pPost=发表回复]
  [equ:pStart=创建主题]
  [equ:pEditOwn=编辑自己的回复]
  [equ:pEditAll=编辑所有回复]
  [equ:pDelOwn=删除自己的回复]
  [equ:pDelAll=删除所有回复]
  [equ:pChat=使用聊天功能]
  [equ:pDownload=下载文件]
  [equ:pAttach=上传附件]
  [equ:pVote=投票]
  [equ:pAdmin=管理员]

  [equ:hdrAvatar=头像：<span class="small">（仅支持 .png 格式；最大 10KB；尺寸：128×128 像素）</span>]
  [equ:hdrLang=界面语言：]
  [equ:hdrSkin=论坛主题：]
  [equ:hdrChangePass=修改密码：]
  [equ:sDefault=（默认）]
  [equ:passNow=当前密码]
  [equ:passNew=新密码]
  [equ:passNew2=再次输入新密码]
  [equ:hdrChangeEmail=修改邮箱地址：]
  [equ:passPass=密码]
  [equ:emailNew=新邮箱地址]
  [equ:btnSave=保存]
  [equ:btnUpload=上传]
  [equ:btnChangePass=修改密码]
  [equ:btnChangeEmail=修改邮箱地址]
  [equ:hdrInterval=最小回复间隔 [秒]：]
  [equ:hdrIncrement=回复间隔自动递增 [秒/回复]：]
  [equ:hdrMaxLen=回复最大长度（0 = 无限制）：]
|
  [equ:hdrDesc=描述：<span class="small">（支持格式化文本）</span>]
  [equ:hdrPermissions=用户权限：]
  [equ:pLogin=登录]
  [equ:pRead=阅读]
  [equ:pPost=发表回复]
  [equ:pStart=创建主题]
  [equ:pEditOwn=编辑自己的回复]
  [equ:pEditAll=编辑所有回复]
  [equ:pDelOwn=删除自己的回复]
  [equ:pDelAll=删除所有回复]
  [equ:pChat=使用聊天功能]
  [equ:pDownload=下载文件]
  [equ:pAttach=上传附件]
  [equ:pVote=投票]
  [equ:pAdmin=管理员]

  [equ:hdrAvatar=头像：<span class="small">（仅支持 .png 格式；最大 10KB；尺寸：128×128 像素）</span>]
  [equ:hdrLang=界面语言：]
  [equ:hdrSkin=论坛主题：]
  [equ:hdrChangePass=修改密码：]
  [equ:sDefault=（默认）]
  [equ:passNow=当前密码]
  [equ:passNew=新密码]
  [equ:passNew2=再次输入新密码]
  [equ:hdrChangeEmail=修改邮箱地址：]
  [equ:passPass=密码]
  [equ:emailNew=新邮箱地址]
  [equ:btnSave=保存]
  [equ:btnUpload=上传]
  [equ:btnChangePass=修改密码]
  [equ:btnChangeEmail=修改邮箱地址]
  [equ:hdrInterval=最小回复间隔 [秒]：]
  [equ:hdrIncrement=回复间隔自动递增 [秒/回复]：]
  [equ:hdrMaxLen=回复最大长度（0 = 无限制）：]
|
  [equ:hdrDesc=Описание потребителя: <span class="small">(форматированный текст)</span>]
  [equ:hdrPermissions=Права пользователя:]
  [equ:pLogin=Вход]
  [equ:pRead=Читать]
  [equ:pPost=Публиковать мнения]
  [equ:pStart=Создавать темы]
  [equ:pEditOwn=Редакция своих постов]
  [equ:pEditAll=Редакция всех постов]
  [equ:pDelOwn=Удалять своих постов]
  [equ:pDelAll=Удалять всех постов]
  [equ:pChat=Чат]
  [equ:pDownload=Скачивать файлы]
  [equ:pAttach=Прикреплять файлы]
  [equ:pVote=Голосовать]
  [equ:pAdmin=Администратор]

  [equ:hdrAvatar=Аватар: <span class="small">(только .png; Максимальный размер: 10KB; Размер: 128x128px)</span>]
  [equ:hdrLang=Язык интерфейса:]
  [equ:hdrSkin=Тема оформления:]
  [equ:hdrChangePass=Сменить пароль:]
  [equ:sDefault=(Как все)]
  [equ:passNow=Старый пароль]
  [equ:passNew=Новый пароль]
  [equ:passNew2=Новый пароль еще раз]
  [equ:hdrChangeEmail=Изменить адрес электронной почты:]
  [equ:passPass=Пароль]
  [equ:emailNew=Новый адрес]
  [equ:btnSave=Записать]
  [equ:btnUpload=Загрузить]
  [equ:btnChangePass=Изменить пароль]
  [equ:btnChangeEmail=Изменить e-mail]
  [equ:hdrInterval=Минимальное время между публикациями [s]:]
  [equ:hdrIncrement=Изменение интервала [s/post]:]
  [equ:hdrMaxLen=Максимальная длина поста (0 = неограниченная):]
|
  [equ:hdrDesc=Description de l'utilisateur: <span class="small">(Texte formaté)</span>]
  [equ:hdrPermissions=Autorisations utilisateur:]
  [equ:pLogin=Connexion]
  [equ:pRead=Lecture]
  [equ:pPost=Poster]
  [equ:pStart=Créer un sujet]
  [equ:pEditOwn=Éditer ses messages]
  [equ:pEditAll=Éditer tous les messages]
  [equ:pDelOwn=Supprimer ses messages]
  [equ:pDelAll=Supprimer tous les messages]
  [equ:pChat=Tchat]
  [equ:pDownload=Télécharger des fichiers]
  [equ:pAttach=Joindre des fichiers]
  [equ:pVote=Vote]
  [equ:pAdmin=Administrateur]

  [equ:hdrAvatar=Avatar:<span class="small">(.png uniquement; Taille maximale: 10KB; Dimensions: 128x128px)</span>]
  [equ:hdrLang=Langue de l'interface:]
  [equ:hdrSkin=Thème:]
  [equ:hdrChangePass=Changement de mot de passe:]
  [equ:sDefault=(Par défaut)]
  [equ:passNow=Mot de passe actuel]
  [equ:passNew=Nouveau mot de passe]
  [equ:passNew2=Retaper le mot de passe]
  [equ:hdrChangeEmail=Changement d'email:]
  [equ:passPass=Mot de passe]
  [equ:emailNew=Nouvel email]
  [equ:btnSave=Sauvegarder]
  [equ:btnUpload=Télécharger]
  [equ:btnChangePass=Sauvergarder]
  [equ:btnChangeEmail=Sauvegarder]
  [equ:hdrInterval=Intervalle minimal de message [s]:]
  [equ:hdrIncrement=Incrément d'intervalle de messages [s/post]:]
  [equ:hdrMaxLen=Longueur maximale du message (0 = illimitée):]
|
  [equ:hdrDesc=Benutzerbeschreibung: <span class="small">(Formatierter Text)</span>]
  [equ:hdrPermissions= Benutzerbefugnisse:]
  [equ:pLogin=Anmelden]
  [equ:pRead=Lesen]
  [equ:pPost=Schreiben]
  [equ:pStart=Themen eröffnen]
  [equ:pEditOwn=Eigene Beiträge ändern]
  [equ:pEditAll=Alle Beiträge ändern]
  [equ:pDelOwn=Eigene Beiträge löschen]
  [equ:pDelAll=Alle Beiträge löschen]
  [equ:pChat=Chatten]
  [equ:pDownload=Dateien herunterladen]
  [equ:pAttach=Dateien anhängen]
  [equ:pVote=Abstimmung]
  [equ:pAdmin=Administrator]

  [equ:hdrAvatar=Avatar: <span class="small">(nur .png; Größe höchstens: 10KB; Abmessungen: 128x128px)</span>]
  [equ:hdrLang=Sprache der Oberfläche:]
  [equ:hdrSkin=Skin des Forums:]
  [equ:hdrChangePass=Passwort ändern:]
  [equ:sDefault=(Standard)]
  [equ:passNow=Aktuelles Passwort]
  [equ:passNew=Neues Passwort]
  [equ:passNew2=Neues Passwort (noch mal)]
  [equ:hdrChangeEmail=E-Mail-Adresse ändern:]
  [equ:passPass=Passwort]
  [equ:emailNew=Neue E-Mail-Adresse]
  [equ:btnSave=Speichern]
  [equ:btnUpload=Hochladen]
  [equ:btnChangePass=Passwort ändern]
  [equ:btnChangeEmail=E-Mail-Adresse ändern]
  [equ:hdrInterval=Zeit zwischen zwei Beiträgen [Sek.]:]
  [equ:hdrIncrement=Zusätzliche Verzögerung bei weiteren Beiträgen [Sek./Beitrag]:]
  [equ:hdrMaxLen=Maximale Nachrichtenlänge (0 = unbegrenzt):]
]

<form class="user_edit_info settings" method="post" action="/!userinfo/[url:[html:[UserName]]]">
  <h2>[const:hdrDesc]</h2>
  <textarea class="user_desc" name="user_desc">[user_desc]</textarea>
  [case:[special:isadmin]||
  <h2>[const:hdrPermissions]</h2>
  <ul class="checkboxes">
  <li><input type="checkbox" [user_perm0]  name="user_perm" id="up0"  value="1"><label for="up0">[const:pLogin]</label></li>
  <li><input type="checkbox" [user_perm1]  name="user_perm" id="up1"  value="2"><label for="up1">[const:pRead]</label></li>
  <li><input type="checkbox" [user_perm2]  name="user_perm" id="up2"  value="4"><label for="up2">[const:pPost]</label></li>
  <li><input type="checkbox" [user_perm3]  name="user_perm" id="up3"  value="8"><label for="up3">[const:pStart]</label></li>
  <li><input type="checkbox" [user_perm4]  name="user_perm" id="up4"  value="16"><label for="up4">[const:pEditOwn]</label></li>
  <li><input type="checkbox" [user_perm5]  name="user_perm" id="up5"  value="32"><label for="up5">[const:pEditAll]</label></li>
  <li><input type="checkbox" [user_perm6]  name="user_perm" id="up6"  value="64"><label for="up6">[const:pDelOwn]</label></li>
  <li><input type="checkbox" [user_perm7]  name="user_perm" id="up7"  value="128"><label for="up7">[const:pDelAll]</label></li>
  <li><input type="checkbox" [user_perm8]  name="user_perm" id="up8"  value="256"><label for="up8">[const:pChat]</label></li>
  <li><input type="checkbox" [user_perm9]  name="user_perm" id="up9"  value="512"><label for="up9">[const:pDownload]</label></li>
  <li><input type="checkbox" [user_perm10] name="user_perm" id="up10" value="1024"><label for="up10">[const:pAttach]</label></li>
  <li><input type="checkbox" [user_perm11] name="user_perm" id="up11" value="2048"><label for="up11">[const:pVote]</label></li>
  <li><input type="checkbox" [user_perm31] name="user_perm" id="up31" value="$80000000"><label for="up31">[const:pAdmin]</label></li>
  </ul>
  <h2>[const:hdrInterval]</h2>
  <input type="text" value="[PostInterval]" name="PostInterval" class="settings" autocomplete="off">
  <h2>[const:hdrIncrement]</h2>
  <input type="text" value="[PostIntervalInc]" name="PostIntervalInc" class="settings" autocomplete="off">
  <h2>[const:hdrMaxLen]</h2>
  <input type="text" value="[MaxPostLen]" name="MaxPostLen" class="settings" autocomplete="off">
  ]
  <input type="hidden" name="ticket" value="[Ticket]">
  <input type="submit" name="save" class="button" value="[const:btnSave]">
</form>

<form class="user_edit_info settings" method="post" enctype="multipart/form-data" action="/!avatar_upload/[url:[html:[UserName]]]">
  <h2>[const:hdrAvatar]</h2>
  <input type="file" class="browse" name="avatar">
  <input type="hidden" name="ticket" value="[Ticket]">
  <input type="submit" name="submit" class="button" value="[const:btnUpload]">
</form>

<form class="user_edit_info settings" method="post" action="/!setskin/[url:[html:[UserName]]]">
  <h2>[const:hdrLang]</h2>
  <select class="userskin" name="user_lang">
    <option value="0" [case:[Lang]|selected="selected"|]>[const:sDefault]</option>
    <option value="1" [case:[Lang]||selected="selected"|]>简体中文</option>
  </select>
  <h2>[const:hdrSkin]</h2>
  <select class="userskin" name="skin">
    <option value="0">[const:sDefault]</option>
    [special:skins=[skin]]
  </select>
  <input type="hidden" name="ticket" value="[Ticket]">
  <input type="submit" name="save" class="button" value="[const:btnSave]">
</form>


[case:[ItIsMe]| |
<form class="user_edit_pass settings" method="post" action="/!changepassword">
  <h2>[const:hdrChangePass]</h2>
  <input type="password" value="" placeholder="[const:passNow]" name="oldpass" class="password" maxlength="1024" autocomplete="off">
  <input type="password" value="" placeholder="[const:passNew]" name="newpass" class="password" maxlength="1024" autocomplete="off">
  <input type="password" value="" placeholder="[const:passNew2]" name="newpass2" class="password" maxlength="1024" autocomplete="off">
  <input type="hidden" name="ticket" value="[Ticket]">
  <input type="submit" name="changepass" class="button" value="[const:btnChangePass]">
</form>

<form class="user_edit_pass settings" method="post" action="/!changemail">
  <h2>[const:hdrChangeEmail]</h2>
  <input type="password" value="" placeholder="[const:passPass]" name="password" class="password" maxlength="1024" autocomplete="off">
  <input type="text" value="[email]" placeholder="[const:emailNew]" name="email" class="email" maxlength="320">
  <input type="hidden" name="ticket" value="[Ticket]">
  <input type="submit" name="changeemail" class="button" value="[const:btnChangeEmail]">
</form>
]

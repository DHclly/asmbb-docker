[case:[special:lang]|
完成密码重置。]
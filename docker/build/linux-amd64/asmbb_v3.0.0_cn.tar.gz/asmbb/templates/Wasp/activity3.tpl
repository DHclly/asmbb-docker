[case:[special:lang]|
注册账号.]
[case:[special:lang]|
用户已退出登录.]
[css:navigation.css]
[css:posts.css]
[css:posteditor.css]

[case:[special:lang]|
  [equ:Caption=主题标题]
  [equ:Content=回复内容]
  [equ:btnPreview=预览]
  [equ:hintPreview=按 Ctrl+Enter 进行预览]
  [equ:btnSubmit=提交]
  [equ:hintSubmit=按 Ctrl+S 进行提交]
  [equ:Attach=附加文件]
  [equ:FileLimit=(数量 ≤ 10, 大小 ≤ 1MB)]
|
  [equ:Caption=主题标题]
  [equ:Content=回复内容]
  [equ:btnPreview=预览]
  [equ:hintPreview=按 Ctrl+Enter 进行预览]
  [equ:btnSubmit=提交]
  [equ:hintSubmit=按 Ctrl+S 进行提交]
  [equ:Attach=附加文件]
  [equ:FileLimit=(数量 ≤ 10, 大小 ≤ 1MB)]
|
  [equ:Caption=Название темы]
  [equ:Content=Содержание поста]
  [equ:btnPreview=Просмотр]
  [equ:hintPreview=Ctrl+Enter для предварительного просмотра]
  [equ:btnSubmit=Отправить]
  [equ:hintSubmit=Ctrl+S чтобы отправить]
  [equ:Attach=Прикрепить файл(ы)]
  [equ:FileLimit=(количество ≤ 10, размер ≤ 1MB)]
|
  [equ:Caption=Titre du sujet]
  [equ:Content=Contenu du message]
  [equ:btnPreview=Prévisualiser]
  [equ:hintPreview=Ctrl+Entrée pour prévisualiser]
  [equ:btnSubmit=Soumettre]
  [equ:hintSubmit=Ctrl+S pour soumettre]
  [equ:Attach=Pièce(s) jointe(s)]
  [equ:FileLimit=(count ≤ 10, size ≤ 1MB)]
|
  [equ:Caption=Titel des Themas]
  [equ:Content=Beitragsinhalt]
  [equ:btnPreview=Vorschau]
  [equ:hintPreview=Strg+Eingabe für eine Vorschau]
  [equ:btnSubmit=Absenden]
  [equ:hintSubmit=Strg+S zum Absenden]
  [equ:Attach=Datei(en) anhängen]
  [equ:FileLimit=(count ≤ 10, size ≤ 1MB)]
]

<div class="ui">
  <a class="ui left" href="../">The thread</a>
  <a class="ui left" href="[case:[id]|[case:[special:page]|.|!by_id]|!by_id]">Back</a>
</div>

<form id="editform" action="[special:cmd]#preview" onsubmit="previewIt(event)" method="post" enctype="multipart/form-data">
    <p>[const:Caption]:</p>
    <h1 class="fakeedit">[caption]</h1>
    [include:edit_toolbar.tpl]
    <p></p>
    [case:[special:canupload]||<p>[const:Attach]: <span class="small">[const:FileLimit]</span></p><input id="browse" type="file" placeholder="Select file to attach" name="attach" multiple="multiple">]
    <p>[const:Content]:</p>
    <textarea class="editor" name="source" id="source">[source]</textarea>
    <div class="panel">
      <input type="submit" name="preview" value="[const:btnPreview]" onclick="this.form.cmd='preview'" title="[const:hintPreview]">
      <input type="submit" name="submit" value="[const:btnSubmit]" onclick="this.form.cmd='submit'" title="[const:hintSubmit]" >
      <input type="hidden" name="ticket" value="[Ticket]" >
    </div>
</form>

<script src="[special:skin]/embeded.js"></script>

<script>
function previewIt(e) {

  if (e.target.cmd === "preview") {
    e.preventDefault();

    var xhr = new XMLHttpRequest();
    xhr.open("POST", "!edit?cmd=preview");

    xhr.onload = function(event){
      if (event.target.status === 200) {
        var prv = document.getElementById("preview");
        var attch = document.getElementById("attachments");
        var resp = JSON.parse(event.target.response);

        prv.innerHTML = resp.preview;
        if (attch) attch.innerHTML = resp.attach_del;
        fixVideos();
      }
      document.getElementById("browse").value = '';
      document.getElementById("source").focus();
    };

    var formData = new FormData(document.getElementById("editform"));
    xhr.send(formData);
    document.getElementById("browse").value = null;
  }
}

document.onkeydown = function(e) {
  var key = e.which || e.keyCode;
  var frm = document.getElementById("editform");
  var stop = true;

  if (e.ctrlKey && key == 13) {
    frm.preview.click();
  } else if (key == 27) {
    window.location.href = "!by_id";
  } else if (e.ctrlKey && key == 83) {
    frm.submit.click();
  } else stop = false;

  if (stop) e.preventDefault();
};


</script>

[case:[special:lang]|
<p>本论坛共有 [threads] 个主题，包含 [posts] 条回复。</p>
<p>我们有 <a href="/!users/">[users] 位注册用户</a>。</p>
<p>最新注册用户：<a class="user" href="/!userinfo/[url:[lastuser]]">[usr:[lastuser]]</a></p>
<p>过去 24 小时内，论坛共有 [guests24] 位访客。</p>
|
<p>本论坛共有 [threads] 个主题，包含 [posts] 条回复。</p>
<p>我们有 <a href="/!users/">[users] 位注册用户</a>。</p>
<p>最新注册用户：<a class="user" href="/!userinfo/[url:[lastuser]]">[usr:[lastuser]]</a></p>
<p>过去 24 小时内，论坛共有 [guests24] 位访客。</p>
|
<p>Этот форум содержит [posts] сообщений в [threads] темах.</p>
<p>У нас <a href="/!users/">[users] зарегистрированных пользователей</a>.</p>
<p>Последний зарегистрированный пользователь: <a class="user" href="/!userinfo/[url:[lastuser]]">[usr:[lastuser]]</a></p>
<p>За последние 24 часа на форуме было [guests24] посетителей.</p>
|
<p>Ce forum contient [posts] message[case:[posts]|s||s] dans [threads] sujet[case:[thread]|s||s].</p>
<p>Nous avons <a href="/!users/">[users] utilisateur[case:[users]|s||s] enregistré[case:[users]|s||s]</a>.</p>
<p>Le dernier utilisateur enregistré est: <a class="user" href="/!userinfo/[url:[lastuser]]">[usr:[lastuser]]</a></p>
<p>Ces dernières 24 heures, il y a eu [guests24] visiteur[case:[guests24]|s||s] sur le forum.</p>
|
<p>Dieses Forum enthält [posts] Beitr[case:[posts]|äge|ag|äge] in [threads] Them[case:[thread]|en|a|en].</p>
<p>Wir haben <a href="/!users/">[users] registrierte[case:[users]||n|] Mitglied[case:[users]|er||er]</a>.</p>
<p>Das neueste Mitglied ist: <a class="user" href="/!userinfo/[url:[lastuser]]">[usr:[lastuser]]</a></p>
<p>In den letzten 24 Stunden hatte das Forum [guests24] Besucher.</p>
]

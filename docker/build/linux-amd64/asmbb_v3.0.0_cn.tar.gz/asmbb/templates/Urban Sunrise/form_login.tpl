[css:login.css]

[case:[special:lang]|
  [equ:btnThreads=主题]
  [equ:ttlLogin=登录]
  [equ:phUser=用户名]
  [equ:phPass=密码]
  [equ:lblPers=保持登录状态]
  [equ:btnSubmit=登录]
  [equ:helpLogin=
      [case:[email_flag]||<p>如果您忘记了密码，请<b><a href="/!resetpassword">点击此处</a></b>。重置次数有限。</p>]
      [case:[special:canregister]||<p>如果您尚未注册，可以<b><a href="/!register">注册新用户</a></b>。</p>]
      <p></p>
      <p>登录状态通过 Cookie（小型文本文件）保存。如果您勾选了“保持登录状态”，系统将在浏览器中保存长期有效的 Cookie。</p>
      <p>如果未勾选此选项（默认情况），则使用临时 Cookie，关闭浏览器后会自动清除。</p>
      <p>当您手动退出论坛时，无论 Cookie 是临时还是长期的，都会被立即清除。</p>
    ]
|
  [equ:btnThreads=主题]
  [equ:ttlLogin=登录]
  [equ:phUser=用户名]
  [equ:phPass=密码]
  [equ:lblPers=保持登录状态]
  [equ:btnSubmit=登录]
  [equ:helpLogin=
      [case:[email_flag]||<p>如果您忘记了密码，请<b><a href="/!resetpassword">点击此处</a></b>。重置次数有限。</p>]
      [case:[special:canregister]||<p>如果您尚未注册，可以<b><a href="/!register">注册新用户</a></b>。</p>]
      <p></p>
      <p>登录状态通过 Cookie（小型文本文件）保存。如果您勾选了“保持登录状态”，系统将在浏览器中保存长期有效的 Cookie。</p>
      <p>如果未勾选此选项（默认情况），则使用临时 Cookie，关闭浏览器后会自动清除。</p>
      <p>当您手动退出论坛时，无论 Cookie 是临时还是长期的，都会被立即清除。</p>
    ]
|
  [equ:btnThreads=Темы]
  [equ:ttlLogin=Включение]
  [equ:phUser=Потребитель]
  [equ:phPass=Пароль]
  [equ:lblPers=Постоянный логин]
  [equ:btnSubmit=Войти]
  [equ:helpLogin=
    [case:[email_flag]||<p>Если вы забыли пароль, <b><a href="/!resetpassword">нажмите здесь</a></b>. У вас ограниченное число попыток сброса.</p>]
    [case:[special:canregister]||<p>Если у вас нет учетной записи, можете <b><a href="/!register">зарегистроваться здесь</a></b>.</p>]
    <p></p>
    <p>Процесс входа использует куки. Если флажок «Постоянный логин» установлен, куки будут постоянно сохраняться в вашем браузере.</p>
    <p>Если флажок «Постоянный логин» не установлен (по умолчанию), AsmBB использует так называемые «сеансовые куки», которые автоматически удаляются при закрытии браузера.</p>
    <p>Когда вы выходите из форума, все куки также удаляются.</p>
  ]
|
  [equ:btnThreads=Sujetss]
  [equ:ttlLogin=Connexion]
  [equ:phUser=Pseudo]
  [equ:phPass=Mot de passe]
  [equ:lblPers=Rester connecté]
  [equ:btnSubmit=Submit]
  [equ:helpLogin=
    [case:[email_flag]||<p>Si vous avez oublié votre mot de passe, <b><a href="/!resetpassword">cliquez ici</a></b>.</p>]
    [case:[special:canregister]||<p>Si vous n'avez pas de compte, vous pouvez <b><a href="/!register">en créer un</a></b>.</p>]
    <p></p>
    <p>La connexion installe un cookie. Si vous cochez la case "Rester connecté", ce cookie sera conservé indéfiniment.</p>
    <p>Si la case "Resté connecté" n'est pas cochée, AsmBB utilisera un cookie de sessions qui sera automatiquement détruit lorsque vous quitterez le site.</p>
    <p>Lorsque vous vous déconnectez, tous les cookies seront également détruits.</p>
  ]
|
  [equ:btnThreads=Themen]
  [equ:ttlLogin=Anmelden]
  [equ:phUser=Benutzername]
  [equ:phPass=Passwort]
  [equ:lblPers=Dauerhaft anmelden]
  [equ:btnSubmit=Absenden]
  [equ:helpLogin=
    [case:[email_flag]||<p>Falls Sie Ihr Passwort vergessen haben, <b><a href="/!resetpassword">klicken Sie hier</a></b>. Ihre Versuche zur Zurücksetzung sind begrenzt.</p>]
    [case:[special:canregister]||<p>Falls Sie noch kein Konto haben, sollten Sie <b><a href="/!register">sich registrieren</a></b>.</p>]
    <p></p>
    <p>Der Anmeldevorgang verwendet Cookies. Falls Sie das Häkchen für die dauerhafte Anmeldung gesetzt haben, so wird es in Ihrem Browser aufbewahrt.</p>
    <p>Ist es nicht gesetzt (das ist der Standard), so verwendet AsmBB so genannte "Sitzungscookies", die automatisch gelöscht werden, wenn Sie Ihren Browser schließen.</p>
    <p>Wenn Sie sich im Forum abmelden, werden ebenfalls alle Cookies entfernt.</p>
  ]
]

<div class="login">
  <form class="login-block" method="post" target="_self" action="/!login">
    <h1>[const:ttlLogin]</h1>

      <h3>[const:phUser]:</h3>
      <input type="text" value="" name="username" autofocus maxlength="256">
      <h3>[const:phPass]:</h3>
      <input type="password" value="" name="password" maxlength="1024" autocomplete="off">
      <p class="pi_tick"><input type="text" value="[special:referer]" name="backlink" id="backlink"></p>
      <p class="checkbox"><input type="checkbox" name="persistent" id="pr" value="1"><label for="pr">[const:lblPers]</label></p>
      <p class="pi_tick"><input type="text" value="[ticket]" name="ticket" id="ticket"></pi_tick>

    <noscript>
       <p class="pi_tick">
         <input type="text" name="submit.x" value="0">
         <input type="text" name="submit.y" value="0">
       </p>
    </noscript>

    <div class="btn-bar">
      <label class="btn" for="submit"><input type="image" name="submit" id="submit" value="Submit">[const:btnSubmit]</label>
    </div>
  </form>
  <article>
    [const:helpLogin]
  </article>
</div>
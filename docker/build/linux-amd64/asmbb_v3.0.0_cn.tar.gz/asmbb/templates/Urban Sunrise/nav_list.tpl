[css:thread_list.css]

[case:[special:lang]|
  [equ:btnNewThread=新建主题]
  [equ:btnMarkRead=标记所有主题已读]
|
  [equ:btnNewThread=新建主题]
  [equ:btnMarkRead=标记所有主题已读]
|
  [equ:btnNewThread=Новая тема]
  [equ:btnMarkRead=Отметить все]
|
  [equ:btnNewThread=Nouveau sujet]
  [equ:btnMarkRead=Tout marquer comme lu]
|
  [equ:btnNewThread=Neues Thema]
  [equ:btnMarkRead=Alle als gelesen kennzeichnen]
]


<div class="navigation3 btn-bar">
  [case:[special:userid]|<a class="btn" href="/!login">[const:btnNewThread]</a>|<a class="btn" href="!markread">[const:btnMarkRead]</a><a class="btn" href="!edit">[const:btnNewThread]</a>]
</div>

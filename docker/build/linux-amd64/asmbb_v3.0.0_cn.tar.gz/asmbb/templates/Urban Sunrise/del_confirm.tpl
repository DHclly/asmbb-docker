[css:delete.css]
[css:markdown.css]

<div class="confirm">
  <form id="editform" method="post">
    <h1 class="msg warning">[case:[special:lang]|
删除[case:[cnt_thread]| |回复和主题|回复]|
删除[case:[cnt_thread]| |回复和主题|回复]|
Удалить [case:[cnt_thread]| |мнение и темы|мнение]|
Supprimer le [case:[cnt_thread]| |sujet et le message|message]|
[case:[cnt_thread]| |Beitrag und Thema|Beitrag] löschen]?</h1>
    [case:[special:lang]|
<p><b>您确定</b>要删除用户 <b>“[usr:[UserName]]”</b> 的回复吗？</p>|
<p><b>您确定</b>要删除用户 <b>“[usr:[UserName]]”</b> 的回复吗？</p>|
<p>Вы <b>действительно</b> хотите удалить мнение <b>"[usr:[UserName]]"</b>?</p>|
<p>Voulez-vous <b>vraiment</b> supprimer le message écrit par <b>"[usr:[UserName]]"</b>?</p>|
<p>Wollen Sie <b>wirklich</b> den Beitrag von <b>"[usr:[UserName]]"</b> löschen?</p>]
    <div class="post_preview">
      <div class="post_text">
        <article>
          [html:[[case:[format]|minimag:[include:minimag_suffix.tpl]|bbcode:][Content]]]
        </article>
      </div>
    </div>
    <p>
[case:[cnt_thread]| |
  [case:[special:lang]|
    这是该主题中的<b>最后一条</b>回复，删除它将<b>同时删除整个主题</b>！|
    这是该主题中的<b>最后一条</b>回复，删除它将<b>同时删除整个主题</b>！|
    Это <b>последний</b> пост в ветке, удаление которого также приведет к <b>удалению темы</b>!|
    Remarquez que ceci est le <b>dernier message</b> dans ce sujet et que <b>le sujet sera supprimé</b> également!|
    Beachten Sie, dass dies der <b>letzte Beitrag</b> im Thema ist und das <b>Thema auch gelöscht</b> werden wird!]
|
  [case:[special:lang]|
    删除它可能会损害该主题！|
    删除它可能会损害该主题！|
    Удаление может навредить обсуждения!|
    Notice, that deletion can break the thread!|
    Beachten Sie, dass Löschen das Thema ruinieren kann!]
]</p>
    <div class="btn-bar">
      <input class="btn" type="submit" value="[case:[special:lang]|删除|删除|Удалить|Supprimer|Löschen]" >
      <a class="btn" href="!by_id">[case:[special:lang]|取消|取消|Отменить|Annuler|Abbrechen]</a>
      <input type="hidden" name="ticket" value="[Ticket]" >
    </div>
  </form>
</div>

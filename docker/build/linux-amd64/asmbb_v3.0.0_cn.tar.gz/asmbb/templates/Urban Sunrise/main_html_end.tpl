<div class="vspacer"></div>

<footer>
  <p>[case:[special:lang]|
    <a href="/!users_online" title="访客最近的操作。">当前在线</a> ：[special:visitors]
  |
    <a href="/!users_online" title="访客最近的操作。">当前在线</a> ：[special:visitors]
  |
    <a href="/!users_online" title="Последние действия потребителей.">Сейчас</a> в сети: [special:visitors]
  |
    Actuellement <a href="/!users_online" title="Activités récentes des visiteurs.">en ligne</a>: [special:visitors]
  |
    Jetzt <a href="/!users_online" title="Letzte Aktivitäten der Besucher.">online</a>: [special:visitors]
  ]
  </p>
  <br>
  [special:stats]
  <br>
  <p>[case:[special:lang]|页面生成时间|页面生成时间|Время обработки страницы|Page chargée en|Seite verarbeitet in]: [special:timestamp] ms</p>
</footer>

<div class="attribution">
  [special:version]; [special:sqliteversion];<br>
  <b>&copy;2016..2020 John Found</b>; Licensed under <b>EUPL</b>. Powered by <b><a href="http://flatassembler.net">Assembly language</a></b> Created with <b><a href="http://fresh.flatassembler.net">Fresh IDE</a></b>
</div>
[special:environment]

</body>
</html>

[css:thread_list.css]

[case:[special:lang]|
  [equ:btnMarkRead=标记所有主题已读]
|
  [equ:btnMarkRead=标记所有主题已读]
|
  [equ:btnMarkRead=Отметить все]
|
  [equ:btnMarkRead=Tout marquer comme lu]
|
  [equ:btnMarkRead=Alle als gelesen kennzeichnen]
]

<div class="navigation3 btn-bar">
  [case:[special:userid]  | |<a class="btn" href="!markread">[const:btnMarkRead]</a>]
</div>

[css:delete.css]
[css:markdown.css]

[case:[special:lang]|
  [equ:hRestore=恢复回复？]
  [equ:pQuestion=<b>您真的</b>要将此回复恢复到之前的版本吗？]
  [equ:btnRestore=恢复]
  [equ:btnCancel=取消]
|
  [equ:hRestore=恢复回复？]
  [equ:pQuestion=<b>您真的</b>要将此回复恢复到之前的版本吗？]
  [equ:btnRestore=恢复]
  [equ:btnCancel=取消]
|
  [equ:hRestore=Восстановить пост?]
  [equ:pQuestion=Вы <b>действительно</b> хотите восстановить это сообщение в предыдущей версии?]
  [equ:btnRestore=Восстановить]
  [equ:btnCancel=Отменить]
|
  [equ:hRestore=Restaurer le message?]
  [equ:pQuestion=Voulez-vous <b>vraiment</b> restaurer ce message dans sa précédente version?]
  [equ:btnRestore=Restaurer]
  [equ:btnCancel=Annuler]
|
  [equ:hRestore=Beitrag wiederherstellen?]
  [equ:pQuestion=Möchten Sie diesen Beitrag <b>wirklich</b> auf die vorherige Version zurücksetzen?]
  [equ:btnRestore=Wiederherstellen]
  [equ:btnCancel=Abbrechen]
]

<div class="confirm">
  <form id="editform" method="post">
    <h1 class="msg warning">[const:hRestore]</h1>
    <p>[const:pQuestion]</p>
    <div class="post_preview">
      <div class="post_text">
        <article>
          [html:[[case:[format]|minimag:[include:minimag_suffix.tpl]|bbcode:][Content]]]
        </article>
      </div>
    </div>
    <div class="btn-bar">
      <input class="btn" type="submit" value="[const:btnRestore]" >
      <a class="btn" href="/[postID]/!history#[version]">[const:btnCancel]</a>
      <input type="hidden" name="version" value="[version]" >
      <input type="hidden" name="ticket" value="[Ticket]" >
    </div>
  </form>
</div>

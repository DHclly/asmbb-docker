<span class="notice">[case:[special:lang]|点击这里|点击这里|Нажмите здесь|Cliquez ici|Klicken Sie hier]</span>
</a></div>
[special:environment]
</body>
</html>
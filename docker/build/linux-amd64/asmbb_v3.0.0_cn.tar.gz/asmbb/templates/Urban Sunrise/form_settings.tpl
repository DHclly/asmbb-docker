[css:settings.css]

[case:[special:lang]|
  [equ:pLogin=登录]
  [equ:pRegister=注册]
  [equ:pRead=浏览主题]
  [equ:pPost=回复主题]
  [equ:pStart=创建主题]
  [equ:pEditOwn=编辑自己的回复]
  [equ:pEditAll=编辑所有回复]
  [equ:pDelOwn=删除自己的回复]
  [equ:pDelAll=删除所有回复]
  [equ:pChat=使用聊天功能]
  [equ:pDownload=下载附件]
  [equ:pAttach=上传附件]
  [equ:pVote=投票]
  [equ:pAdmin=管理员]
  [equ:ttlInterval=回复最小间隔时间 [秒]]
  [equ:ttlIntervalInc=自动增加回复间隔时间 [秒/回复]]
  [equ:ttlMaxPostLength=回复最大长度（0 = 无限制）]
  [equ:ttlActivationTime=账号激活最短等待时间 [秒]]

  [equ:ttlSettings=论坛引擎设置]
  [equ:btnSave=保存]
  [equ:tabHTML=HTML/CSS]
  [equ:ttlTitle=标题]
  [equ:ttlHeader=论坛页眉]
  [equ:ttlDesc=描述]
  [equ:ttlKeywords=关键词]
  [equ:ttlEmbeded=嵌入式 CSS]
  [equ:tabServer=服务器]
  [equ:ttlHost=主机地址]
  [equ:ttlSMTP=SMTP 服务器/端口]
  [equ:ttlPipe=邮件发送方式]
  [equ:ttlAccount=SMTP 账号]
  [equ:ttlConfirm=通过电子邮件验证]
  [equ:tabPermissions=访问权限]
  [equ:ttlPermNew=新用户权限]
  [equ:ttlPermGuests=访客权限]
  [equ:tabFeatures=功能选项]
  [equ:ttlLang=默认语言]
  [equ:ttlPgLen=每页显示数量]
  [equ:ttlSkin=默认主题样式]
  [equ:ttlMobile=移动端主题样式]
  [equ:ttlChat=实时聊天功能]
  [equ:ttlMarkup=支持的格式语法：<small>（至少需选择一种）</small>]
  [equ:tabEncryption=加密设置]
  [equ:ttlNewPassword=新密钥]
  [equ:helpEncryption=
    <p>更换加密密钥是一个耗时的过程，在此期间访客将无法访问网站。</p>
    <p>数据库加密操作存在潜在风险。请务必先创建备份，并在加密成功完成后删除备份文件。</p>
    <p>启用加密后，每次重启 AsmBB 都需要重新输入密钥。</p>
  ]
|
  [equ:pLogin=登录]
  [equ:pRegister=注册]
  [equ:pRead=浏览主题]
  [equ:pPost=回复主题]
  [equ:pStart=创建主题]
  [equ:pEditOwn=编辑自己的回复]
  [equ:pEditAll=编辑所有回复]
  [equ:pDelOwn=删除自己的回复]
  [equ:pDelAll=删除所有回复]
  [equ:pChat=使用聊天功能]
  [equ:pDownload=下载附件]
  [equ:pAttach=上传附件]
  [equ:pVote=投票]
  [equ:pAdmin=管理员]
  [equ:ttlInterval=回复最小间隔时间 [秒]]
  [equ:ttlIntervalInc=自动增加回复间隔时间 [秒/回复]]
  [equ:ttlMaxPostLength=回复最大长度（0 = 无限制）]
  [equ:ttlActivationTime=账号激活最短等待时间 [秒]]

  [equ:ttlSettings=论坛引擎设置]
  [equ:btnSave=保存]
  [equ:tabHTML=HTML/CSS]
  [equ:ttlTitle=标题]
  [equ:ttlHeader=论坛页眉]
  [equ:ttlDesc=描述]
  [equ:ttlKeywords=关键词]
  [equ:ttlEmbeded=嵌入式 CSS]
  [equ:tabServer=服务器]
  [equ:ttlHost=主机地址]
  [equ:ttlSMTP=SMTP 服务器/端口]
  [equ:ttlPipe=邮件发送方式]
  [equ:ttlAccount=SMTP 账号]
  [equ:ttlConfirm=通过电子邮件验证]
  [equ:tabPermissions=访问权限]
  [equ:ttlPermNew=新用户权限]
  [equ:ttlPermGuests=访客权限]
  [equ:tabFeatures=功能选项]
  [equ:ttlLang=默认语言]
  [equ:ttlPgLen=每页显示数量]
  [equ:ttlSkin=默认主题样式]
  [equ:ttlMobile=移动端主题样式]
  [equ:ttlChat=实时聊天功能]
  [equ:ttlMarkup=支持的格式语法：<small>（至少需选择一种）</small>]
  [equ:tabEncryption=加密设置]
  [equ:ttlNewPassword=新密钥]
  [equ:helpEncryption=
    <p>更换加密密钥是一个耗时的过程，在此期间访客将无法访问网站。</p>
    <p>数据库加密操作存在潜在风险。请务必先创建备份，并在加密成功完成后删除备份文件。</p>
    <p>启用加密后，每次重启 AsmBB 都需要重新输入密钥。</p>
  ]
|
  [equ:pLogin=Вход]
  [equ:pRegister=Регистрироваться]
  [equ:pRead=Читать]
  [equ:pPost=Публиковать мнения]
  [equ:pStart=Создавать темы]
  [equ:pEditOwn=Редакция своих постов]
  [equ:pEditAll=Редакция всех постов]
  [equ:pDelOwn=Удалять своих постов]
  [equ:pDelAll=Удалять всех постов]
  [equ:pChat=Чат]
  [equ:pDownload=Скачивать файлы]
  [equ:pAttach=Прикреплять файлы]
  [equ:pVote=Голосовать]
  [equ:pAdmin=Администратор]
  [equ:ttlInterval=Минимальное время между публикациями [s]]
  [equ:ttlIntervalInc=Изменение интервала [s/post]]
  [equ:ttlMaxPostLength=Максимальная длина поста (0 = неограниченная)]
  [equ:ttlActivationTime=Минимальное время для активации [s]]

  [equ:ttlSettings=Настройки форума]
  [equ:btnSave=Запись]
  [equ:tabHTML=HTML/CSS]
  [equ:ttlTitle=Название форума]
  [equ:ttlHeader=Заголовок форума]
  [equ:ttlDesc=Описание]
  [equ:ttlKeywords=Ключевые слова]
  [equ:ttlEmbeded=Встроенный CSS]
  [equ:tabServer=Сервер]
  [equ:ttlHost=Хост]
  [equ:ttlSMTP=SMTP сервер/порт]
  [equ:ttlPipe=Качать письма через]
  [equ:ttlAccount=SMTP акаунт]
  [equ:ttlConfirm=Потверждения через имейл]
  [equ:tabPermissions=Права доступа]
  [equ:ttlPermNew=Для новых пользователей]
  [equ:ttlPermGuests=Для гостей]
  [equ:tabFeatures=Функции]
  [equ:ttlLang=Язык интерфейса]
  [equ:ttlPgLen=Длина страницы]
  [equ:ttlSkin=Оформление по умолчанию]
  [equ:ttlMobile=Оформление для мобильных устройств]
  [equ:ttlChat=Включить чат]
  [equ:ttlMarkup=Языки разметки: <small>(должен быть выбран хотя бы один)</small>]
  [equ:tabEncryption=Шифрование]
  [equ:ttlNewPassword=Новый ключ шифрования]
  [equ:helpEncryption=
    <p>Изменение ключа шифрования является медленной процедурой, во время которой посетители не могут получить доступ к сайту.</p>
    <p>Процесс шифрования базы данных потенциально опасен. Сделайте резервное копие и удалите его после успешного завершения процедуры.</p>
    <p>Зашифрованная база данных требует ввода ключа после каждого перезапуска AsmBB.</p>
  ]
|
  [equ:pLogin=Connexion]
  [equ:pRegister=S'enegistrer]
  [equ:pRead=Lecture]
  [equ:pPost=Poster]
  [equ:pStart=Créer un sujet]
  [equ:pEditOwn=Éditer ses messages]
  [equ:pEditAll=Éditer tous les messages]
  [equ:pDelOwn=Supprimer ses messages]
  [equ:pDelAll=Supprimer tous les messages]
  [equ:pChat=Tchat]
  [equ:pDownload=Télécharger des fichiers]
  [equ:pAttach=Joindre des fichiers]
  [equ:pVote=Vote]
  [equ:pAdmin=Administrateur]
  [equ:ttlInterval=Intervalle minimal de message [s]]
  [equ:ttlIntervalInc=Incrément d'intervalle de messages [s/post]]
  [equ:ttlMaxPostLength=Longueur maximale du message (0 = illimitée)]
  [equ:ttlActivationTime=Temps d'activation minimal [s]]

  [equ:ttlSettings=Paramètres du forum]
  [equ:btnSave=Écrire]
  [equ:tabHTML=HTML/CSS]
  [equ:ttlTitle=Titre du forum]
  [equ:ttlHeader=En-tête de forum]
  [equ:ttlDesc=Description]
  [equ:ttlKeywords=Mots clés]
  [equ:ttlEmbeded=CSS intégré]
  [equ:tabServer=Serveur]
  [equ:ttlHost=Host]
  [equ:ttlSMTP=SMTP serveur/port]
  [equ:ttlPipe=Pipe les emails à travers]
  [equ:ttlAccount=SMTP account]
  [equ:ttlConfirm=Confirmer par email]
  [equ:tabPermissions=Permissions]
  [equ:ttlPermNew=Pour les nouveaux utilisateurs]
  [equ:ttlPermGuests=Pour les invités]
  [equ:tabFeatures=Fonctionnalités]
  [equ:ttlLang=Langue de l'interface par défaut]
  [equ:ttlPgLen=Longueur de page]
  [equ:ttlSkin=Thème par défaut]
  [equ:ttlMobile=Thème mobile par défaut]
  [equ:ttlChat=Activer le tchat]
  [equ:ttlMarkup=Langages de marquage disponibles: <small>(au moins un doit être sélectionné)</small>]
  [equ:tabEncryption=Chiffrement]
  [equ:ttlNewPassword=Nouvelle clé de cryptage]
  [equ:helpEncryption=
    <p>The change of the encryption key is relatively long procedure. During it the forum will be not accessible.</p>
    <p>This procedure is potentially dangerous. Make a backup of the database before encrypting. When encryption finishes successfully delete this backup.</p>
    <p>If the database is encrypted, you must enter a password on every AsmBB engine restart.</p>
  ]
|
  [equ:pLogin=Anmelden]
  [equ:pRegister=Registrieren]
  [equ:pRead=Lesen]
  [equ:pPost=Schreiben]
  [equ:pStart=Themen eröffnen]
  [equ:pEditOwn=Eigene Beiträge ändern]
  [equ:pEditAll=Alle Beiträge ändern]
  [equ:pDelOwn=Eigene Beiträge löschen]
  [equ:pDelAll=Alle Beiträge löschen]
  [equ:pChat=Chatten]
  [equ:pDownload=Dateien herunterladen]
  [equ:pAttach=Dateien anhängen]
  [equ:pVote=Abstimmung]
  [equ:pAdmin=Administrator]
  [equ:ttlInterval=Zeit zwischen zwei Beiträgen [Sek.]]
  [equ:ttlIntervalInc=Zusätzliche Verzögerung bei weiteren Beiträgen [Sek./Beitrag]]
  [equ:ttlMaxPostLength=Maximale Nachrichtenlänge (0 = unbegrenzt)]
  [equ:ttlActivationTime=Minimale Aktivierungszeit [s]]

  [equ:ttlSettings=Einstellungen der Forenengine]
  [equ:btnSave=Speichern]
  [equ:tabHTML=HTML/CSS]
  [equ:ttlTitle=Titel des Forums]
  [equ:ttlHeader=Kopfzeile des Forums]
  [equ:ttlDesc=Beschreibung]
  [equ:ttlKeywords=Schlüsselwörter]
  [equ:ttlEmbeded=Eingebettetes CSS]
  [equ:tabServer=Server]
  [equ:ttlHost=Host]
  [equ:ttlSMTP=SMTP-Server/Port]
  [equ:ttlPipe=E-Mails in folgendem Programm verarbeiten]
  [equ:ttlAccount=SMTP-Konto]
  [equ:ttlConfirm=E-Mail-Bestätigung]
  [equ:tabPermissions=Befugnisse]
  [equ:ttlPermNew=Für neue Mitglieder]
  [equ:ttlPermGuests=Für Gäste]
  [equ:tabFeatures=Funktionen]
  [equ:ttlLang=Standard-UI-Sprache]
  [equ:ttlPgLen=Seitenlänge]
  [equ:ttlSkin=Standardskin]
  [equ:ttlMobile=Mobiler Standardskin]
  [equ:ttlChat=Chat aktivieren]
  [equ:ttlMarkup=Verfügbare Formatierungssprachen: <small>(mindestens eine muss ausgewählt werden)</small>]
  [equ:tabEncryption=Verschlüsselung]
  [equ:ttlNewPassword=Neuer Verschlüsselungspasswort]
  [equ:helpEncryption=
      <p>Das Ändern des Schlüssels ist ein vergleichsweise langwieriger Vorgang. Währenddessen wird das Forum nicht verfügbar sein.</p>
      <p>Diese Prozedur ist potenziell gefährlich. Fertigen Sie eine Sicherung der Datenbank vor der Verschlüsselung an. Wenn die Verschlüsselung erfolgreich abgeschlossen ist, löschen Sie diese Sicherung.</p>
      <p>Sofern die Datenbank verschlüsselt ist, müssen Sie bei jedem Neustart der AsmBB-Engine ein Passwort eingeben.</p>
  ]
]


<div class="set_page">
<form class="settings msgbox" method="post" action="/!settings">
  <h1>[const:ttlSettings]</h1>

  <div class="dropdown tabbed-form">

    <input id="tab1" name="tabselector" type="radio" value="0" [case:[tabselector]|checked|]>
    <label for="tab1">[const:tabHTML]</label>
    <section>
      <h3>[const:ttlTitle]:</h3>
      <input type="text" value="[forum_title]" name="forum_title" class="settings" maxlength="512">

      <h3>[const:ttlHeader]:</h3>
      <textarea rows="8" class="settings" name="forum_header">[forum_header]</textarea>

      <h3>[const:ttlDesc]:</h3>
      <input type="text" value="[description]" name="description" class="settings" maxlength="256">

      <h3>[const:ttlKeywords]:</h3>
      <input type="text" value="[keywords]" name="keywords" class="settings" maxlength="256">

      <p class="checkbox"><input type="checkbox" [embeded_css] name="embeded_css" id="embeded_css"><label for="embeded_css">[const:ttlEmbeded]</label></p>
    </section>

    <input id="tab2" name="tabselector" type="radio" value="1" [case:[tabselector]||checked|]>
    <label for="tab2">[const:tabServer]</label>
    <section>
      <h3>[const:ttlHost]:</h3>
      <input type="text" value="[host]" name="host" class="settings" maxlength="320">

      <h3>[const:ttlSMTP]:</h3>
      <input type="text" value="[smtp_addr]" name="smtp_addr" class="settings" maxlength="256">
      <input type="text" value="[smtp_port]" name="smtp_port" class="settings" maxlength="5">

      <h3>[const:ttlPipe]:</h3>
      <input type="text" value="[smtp_exec]" name="smtp_exec" class="settings" maxlength="256">

      <h3>[const:ttlAccount]:</h3>
      <input type="text" value="[smtp_user]" name="smtp_user" class="settings" maxlength="256">

      <p class="checkbox"><input type="checkbox" [email_confirm] name="email_confirm" id="email_confirm" class="checkbox"><label for="email_confirm">[const:ttlConfirm]</label></p>
    </section>

    <input id="tab3" name="tabselector" type="radio" value="2" [case:[tabselector]|||checked|]>
    <label for="tab3">[const:tabPermissions]</label>
    <section>
      <h3>[const:ttlPermNew]:</h3>
      <ul class="checkboxes checkbox">
        <li><input type="checkbox" [user_perm0]  name="user_perm" id="up0"  value="1"><label for="up0">[const:pLogin]</label></li>
        <li><input type="checkbox" [user_perm1]  name="user_perm" id="up1"  value="2"><label for="up1">[const:pRead]</label></li>
        <li><input type="checkbox" [user_perm2]  name="user_perm" id="up2"  value="4"><label for="up2">[const:pPost]</label></li>
        <li><input type="checkbox" [user_perm3]  name="user_perm" id="up3"  value="8"><label for="up3">[const:pStart]</label></li>
        <li><input type="checkbox" [user_perm4]  name="user_perm" id="up4"  value="16"><label for="up4">[const:pEditOwn]</label></li>
        <li><input type="checkbox" [user_perm5]  name="user_perm" id="up5"  value="32"><label for="up5">[const:pEditAll]</label></li>
        <li><input type="checkbox" [user_perm6]  name="user_perm" id="up6"  value="64"><label for="up6">[const:pDelOwn]</label></li>
        <li><input type="checkbox" [user_perm7]  name="user_perm" id="up7"  value="128"><label for="up7">[const:pDelAll]</label></li>
        <li><input type="checkbox" [user_perm8]  name="user_perm" id="up8"  value="256"><label for="up8">[const:pChat]</label></li>
        <li><input type="checkbox" [user_perm9]  name="user_perm" id="up9"  value="512"><label for="up9">[const:pDownload]</label></li>
        <li><input type="checkbox" [user_perm10] name="user_perm" id="up10" value="1024"><label for="up10">[const:pAttach]</label></li>
        <li><input type="checkbox" [user_perm11] name="user_perm" id="up11" value="2048"><label for="up11">[const:pVote]</label></li>
        <li><input type="checkbox" [user_perm31] name="user_perm" id="up31" value="$80000000"><label for="up31">[const:pAdmin]</label></li>
      </ul>
      <h3>[const:ttlInterval]:</h3>
      <input type="text" value="[post_interval]" name="post_interval" class="settings" maxlength="256">
      <h3>[const:ttlIntervalInc]:</h3>
      <input type="text" value="[post_interval_inc]" name="post_interval_inc" class="settings" maxlength="256">
      <h3>[const:ttlMaxPostLength]:</h3>
      <input type="text" value="[max_post_length]" name="max_post_length" class="settings" maxlength="256">
      <h3>[const:ttlPermGuests]:</h3>
      <ul class="checkboxes checkbox">
        <li><input type="checkbox" [anon_perm0]  name="anon_perm" id="ap0"  value="1"><label for="ap0">[const:pRegister]</label></li>
        <li><input type="checkbox" [anon_perm1]  name="anon_perm" id="ap1"  value="2"><label for="ap1">[const:pRead]</label></li>
        <li><input type="checkbox" [anon_perm8]  name="anon_perm" id="ap8"  value="256"><label for="ap8">[const:pChat]</label></li>
        <li><input type="checkbox" [anon_perm9]  name="anon_perm" id="ap9"  value="512"><label for="ap9">[const:pDownload]</label></li>
      </ul>
      <h3>[const:ttlActivationTime]:</h3>
      <input type="text" value="[activate_min_interval]" name="activate_min_interval" class="settings" maxlength="256">
    </section>

    <input id="tab4" name="tabselector" type="radio" value="3" [case:[tabselector]||||checked|]>
    <label for="tab4">[const:tabFeatures]</label>
    <section>
      <h3>[const:ttlLang]:</h3>
      <select class="settings" name="default_lang">
        <option value="0" [case:[default_lang]|selected="selected"|]>简体中文</option>
      </select>

      <h3>[const:ttlPgLen]:</h3>
      <input type="text" value="[page_length]" name="page_length" class="settings" maxlength="256">

      <h3>[const:ttlSkin]:</h3>
      <select class="settings" name="default_skin" >[special:skins=[default_skin]]</select>

      <h3>[const:ttlMobile]:</h3>
      <select class="settings" name="default_mobile_skin">[special:skins=[default_mobile_skin]]</select>

      <p class="checkbox"><input type="checkbox" [chat_enabled] name="chat_enabled" id="chat_enabled"><label for="chat_enabled">[const:ttlChat]</label></p>

      <h3>[const:ttlMarkup]</h3>
      <p class="checkbox">
        <input type="checkbox" [markup0]  name="markups" id="mu0"  value="1"><label for="mu0">MiniMag (类似 markdown)</label>
        <input type="checkbox" [markup1]  name="markups" id="mu1"  value="2"><label for="mu1">BBCode</label>
      </p>
    </section>

    <input id="tab5" name="tabselector" type="radio" value="4" [case:[tabselector]|||||checked|]>
    <label for="tab5">[const:tabEncryption]</label>
    <section>
      <div>
        <h3>[const:ttlNewPassword]:</h3>
        <input type="text" value="" placeholder="Encryption password" name="password" class="settings" maxlength="1024">
      </div>
      <p class="checkbox"><input type="checkbox" name="decrypt" id="cbdecr" value="1"><label for="cbdecr">Remove the encryption</label></p>
      <article>
        [const:helpEncryption]
      </article>
    </section>

  </div>

  <input type="hidden" name="ticket" value="[Ticket]" >
  <div class="btn-bar">
    <input type="submit" name="save" class="btn" value="[const:btnSave]">
    <input type="reset" name="save" class="btn" value="重置">
    [case:[message]||<div id="message" class="msg [case:[error]|info|error]">[message]</div>]
  </div>
</form>
</div>

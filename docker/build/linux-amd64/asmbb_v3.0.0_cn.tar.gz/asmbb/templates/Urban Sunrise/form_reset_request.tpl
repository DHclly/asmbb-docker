[css:login.css]

[case:[special:lang]|
  [equ:ttlRequest=密码重置申请]
  [equ:phUser=用户名]
  [equ:phEmail=E-mail]
  [equ:btnSubmit=提交]
  [equ:helpRequest=
    <p>您每24小时只有一次重置机会。</p>
    <p>请输入您的用户名以及与账户关联的邮箱地址。</p>
    <p>点击“提交”后，系统将向您发送一封包含继续操作链接的邮件。</p>
    <p>请注意，如果您注册时填写了无效的邮箱地址，重置流程将无法成功。</p>
    <p>在这种情况下，唯一的解决办法是创建一个新账户。</p>
  ]
|
  [equ:ttlRequest=密码重置申请]
  [equ:phUser=用户名]
  [equ:phEmail=E-mail]
  [equ:btnSubmit=提交]
  [equ:helpRequest=
    <p>您每24小时只有一次重置机会。</p>
    <p>请输入您的用户名以及与账户关联的邮箱地址。</p>
    <p>点击“提交”后，系统将向您发送一封包含继续操作链接的邮件。</p>
    <p>请注意，如果您注册时填写了无效的邮箱地址，重置流程将无法成功。</p>
    <p>在这种情况下，唯一的解决办法是创建一个新账户。</p>
  ]
|
  [equ:ttlRequest=Запрос сброса пароля]
  [equ:phUser=Потребитель]
  [equ:phEmail=Адрес электронной почты]
  [equ:btnSubmit=Отправить]
  [equ:helpRequest=
    <p>У вас есть одна попытка сброса за 24 часа.</p>
    <p>Введите ваше имя пользователя и адрес электронной почты, связанный с вашей учетной записью.</p>
    <p>Когда вы нажимаете «отправить», на адрес электронной почты вашей учетной записи будет отправлено письмо со ссылкой для сброса пароля.</p>
    <p>Обратите внимание, что если вы использовали неверный адрес электронной почты при регистрации, процесс сброса не удастся.</p>
    <p>В этом случае единственный вариант - создать новую учетную запись.</p>
  ]
|
  [equ:ttlRequest=Réinitialiser la demande de mot de passe]
  [equ:phUser=Nom d'utilisateur]
  [equ:phEmail=Email]
  [equ:btnSubmit=Envoyer]
  [equ:helpRequest=
    <p>Vous avez droit à une réinitialisation toutes les 24h.</p>
    <p>Remplissez le champ nom d'utilisateur et e-mail associé à votre compte.</p>
    <p>Lorque vous cliquez sur "Envoyer", un email comptenant un lien de réinitialisation de mot de passe sera envoyé à votre adresse email.</p>
    <p>Si vous avez fourni un email invalide lors de votre inscription, cela ne fonctionnera pas.</p>
    <p>Dans ce cas, la seule solution est de recréer un compte.</p>
  ]
|
  [equ:ttlRequest=Anforderung der Passwortzurücksetzung]
  [equ:phUser=Benutzername]
  [equ:phEmail=E-Mail-Adresse]
  [equ:btnSubmit=Absenden]
  [equ:helpRegister=
    <p>Ihnen steht eine Zurücksetzung je 24 Stunden zur Verfügung.</p>
    <p>Geben Sie Ihren Benutzernamen und die E-Mail-Adresse Ihres Benutzerkontos an.</p>
    <p>Wenn Sie auf "Absenden" klicken, wird eine E-Mail mit einem Link zur Zurücksetzung des Passworts an Ihre E-Mail-Adresse gesendet.</p>
    <p>Beachten Sie, dass, falls Sie bei der Registrierung eine ungültige E-Mail-Adresse angegeben haben, dieser Vorgang fehlschlagen wird.</p>
    <p>In diesem Fall ist Ihre einzige Option die Registrierung eines neuen Kontos.</p>
  ]
]

<div class="login">
  <form method="post" action="/!resetpassword/1">
    <h1>[const:ttlRequest]</h1>

    <h3>[const:phUser]:</h3>
    <input type="text" value="" name="username" maxlength="256" autofocus>
    <h3>[const:phEmail]:</h3>
    <input type="text" value="" name="email" maxlength="320">

    <input type="hidden" value="[ticket]" name="ticket" id="ticket">
    <p></p>
    <div class="btn-bar"><input type="submit" name="submit" class="btn" value="[const:btnSubmit]"></div>
  </form>
  <article>
    [const:helpRequest]
  </article>
</div>

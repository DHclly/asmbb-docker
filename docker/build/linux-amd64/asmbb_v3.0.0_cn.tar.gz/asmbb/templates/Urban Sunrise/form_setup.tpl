[css:common.css]
[css:settings.css]

<div class="set_page">
<form class="settings" method="post" action="/!adminrulez">
  <h1>管理员账号设置</h1>
  <h3>管理员昵称:</h3><input type="text" value="" name="admin" class="settings" size="30" maxlength="320">
  <h3>管理员邮箱:</h3><input type="text" value="" name="email" class="settings" size="30" maxlength="320">
  <h3>请输入密码:</h3><input type="password" value="" name="password" class="settings" size="30" maxlength="1024">
  <h3>再次输入密码:</h3><input type="password" value="" name="password2" class="settings" size="30" maxlength="1024">

  <input type="submit" name="submit" class="button" value="设置管理员">
</form>
</div>
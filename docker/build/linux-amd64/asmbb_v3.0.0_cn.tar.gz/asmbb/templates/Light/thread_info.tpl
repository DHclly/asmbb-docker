[case:[special:lang]|
  [equ:ttlPinned=置顶]
  [equ:ttlLimited=受限访问主题]
  [equ:ttlUnread=[case:[Unread]|跳转到最后|跳转到第一条未读]]
  [equ:tPosts=回复[case:[PostCount]|||]]
  [equ:ttlMark=将该主题标记为已读]
  [equ:tViews=浏览[case:[ReadCount]|||]]
  [equ:Posters=参与者]
  [equ:Invited=受邀者]
  [equ:Tags=标签]
  [equ:Rating=评分]
|
  [equ:ttlPinned=置顶]
  [equ:ttlLimited=受限访问主题]
  [equ:ttlUnread=[case:[Unread]|跳转到最后|跳转到第一条未读]]
  [equ:tPosts=回复[case:[PostCount]|||]]
  [equ:ttlMark=将该主题标记为已读]
  [equ:tViews=浏览[case:[ReadCount]|||]]
  [equ:Posters=参与者]
  [equ:Invited=受邀者]
  [equ:Tags=标签]
  [equ:Rating=评分]
|
  [equ:ttlPinned=Прикрепленная на верху]
  [equ:ttlLimited=Тема ограниченным доступом]
  [equ:ttlUnread=[case:[Unread]|Нет новых сообщений|К первому непрочитанному]]
  [equ:tPosts=сообщени[case:[PostCount]|й|е|й]]
  [equ:ttlMark=Отметить тему прочитанной]
  [equ:tViews=просмотр[case:[ReadCount]|ов||ов]]
  [equ:Posters=Участники: ]
  [equ:Invited=Приглашенные: ]
  [equ:Rating=Рейтинг]
|
  [equ:ttlPinned=Sujet épinglé]
  [equ:ttlLimited=Sujet à accès limité]
  [equ:ttlUnread=[case:[Unread]|Pas de messages non-lus|Allez au premier non-lu]]
  [equ:tPosts=post[case:[PostCount]|s||s]]
  [equ:ttlMark=Marquer le sujet comme lu]
  [equ:tViews=vue[case:[ReadCount]|s||s]]
  [equ:Posters=Participants: ]
  [equ:Invited=Invités: ]
  [equ:Rating=Évaluation]
|
  [equ:ttlPinned=Angeheftetes Thema]
  [equ:ttlLimited=Beschränktes Thema]
  [equ:ttlUnread=[case:[Unread]|Keine ungelesenen Beiträge|Springe zum ersten ungelesenen Beitrag]]
  [equ:tPosts=Beitr[case:[PostCount]|äge|ag|äge]]
  [equ:ttlMark=Thema als gelesen kennzeichnen]
  [equ:tViews=[case:[ReadCount]|Ansichten|Ansicht|Ansichten]]
  [equ:Posters=Teilnehmer: ]
  [equ:Invited=Eingeladen: ]
  [equ:Rating=Bewertung]
]

<div class="thread_summary">
      [case:[Pinned]||<img class="pinned" src="[special:skin]/_images/pinned.png" alt="!" title="[const:ttlPinned]">]
      [case:[limited]||<img height="32" width="32" class="unread" src="[special:skin]/_images/limited.svg" alt="#" title="[const:ttlLimited]">]
      [case:[Unread]||<a href="[Slug]/!unread">]<img height="32" width="32" class="unread" src="[special:skin]/_images/posts[case:[Unread]|_gray|].svg" alt="[case:[Unread]||&gt;]" title="[const:ttlUnread]">[case:[Unread]||</a>]
  <div class="thread_link">
    <a class="thread_link" href="[Slug]/">[Caption]</a><br>
    <label><input type="checkbox" class="collapseit"><ul class="small comma posters">[const:Posters][html:[Posters]]</ul></label>
    [case:[limited]||<label><input type="checkbox" class="collapseit"><ul class="small comma invited">[const:Invited][html:[Invited]]</ul></label>]
  </div>
  <ul class="thread_tags">[html:[ThreadTags]]</ul>
  <div class="col_date">
      [PostCount] [const:tPosts]<br>
    [case:[Unread]||<div class="unread_cnt">( [Unread] unread ) <a href="[Slug]/!markread" title="[const:ttlMark]"><img width="16" height="16" src="[special:skin]/_images/markread.svg" alt="X"></a></div>]
    <span class="small">[TimeChanged]</span>
  </div>
  <div class="col_cnt">
    [ReadCount] [const:tViews]<br>
    [const:Rating]: <span id="thread_rating[id]">[Rating]</span>
  </div>
</div>
